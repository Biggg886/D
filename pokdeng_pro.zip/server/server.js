
import express from "express";
import http from "http";
import { Server } from "socket.io";
import path from "path";

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = 5000;
const rooms = {};

function createDeck() {
  const suits = ["spades","hearts","diamonds","clubs"];
  const ranks = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"];
  let deck = [];
  for (let s of suits) for (let r of ranks) deck.push({ suit: s, rank: r });
  return deck.sort(() => Math.random() - 0.5);
}

io.on("connection", socket => {

  socket.on("create-room", name => {
    const id = Math.random().toString(36).substring(2,8).toUpperCase();
    rooms[id] = { host: socket.id, players:[{id:socket.id,name,hand:[]}], deck:[] };
    socket.join(id);
    io.to(id).emit("update", rooms[id]);
  });

  socket.on("join-room", ({roomId,name}) => {
    if(!rooms[roomId]) return;
    rooms[roomId].players.push({id:socket.id,name,hand:[]});
    socket.join(roomId);
    io.to(roomId).emit("update", rooms[roomId]);
  });

  socket.on("start", roomId => {
    const room = rooms[roomId];
    room.deck = createDeck();
    room.players.forEach(p=>p.hand=[room.deck.pop(),room.deck.pop()]);
    io.to(roomId).emit("update", room);
  });

  socket.on("hit", roomId => {
    const room = rooms[roomId];
    const p = room.players.find(p=>p.id===socket.id);
    if(p && p.hand.length<3) p.hand.push(room.deck.pop());
    io.to(roomId).emit("update", room);
  });

  socket.on("disconnect", ()=>{
    for(const r in rooms){
      rooms[r].players = rooms[r].players.filter(p=>p.id!==socket.id);
      if(rooms[r].players.length===0) delete rooms[r];
    }
  });
});

app.use(express.static(path.resolve("client/dist")));
app.get("*",(req,res)=>res.sendFile(path.resolve("client/dist/index.html")));

server.listen(PORT,()=>console.log("PokDeng running on "+PORT));
