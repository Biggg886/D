
import { useEffect, useState } from 'react'
import { io } from 'socket.io-client'

const socket = io()

function Card({rank,suit}){
  const m={spades:'S',hearts:'H',diamonds:'D',clubs:'C'}
  return <img src={`/cards/${rank}${m[suit]}.png`} className="card"/>
}

export default function App(){
  const [name,setName]=useState('')
  const [room,setRoom]=useState(null)

  useEffect(()=>{
    socket.on("update", data=>setRoom(data))
  },[])

  if(!room)
    return (
      <div className="center">
        <h1>ป๊อกเด้ง</h1>
        <input placeholder="ชื่อ" onChange={e=>setName(e.target.value)}/>
        <button onClick={()=>socket.emit("create-room",name)}>สร้างห้อง</button>
      </div>
    )

  return (
    <div className="table">
      <h2>ห้อง</h2>
      <button onClick={()=>socket.emit("start",Object.keys(room)[0])}>เริ่ม</button>
      <div className="players">
        {room.players.map(p=>(
          <div key={p.id}>
            <h4>{p.name}</h4>
            <div className="hand">
              {p.hand.map((c,i)=><Card key={i} {...c}/>)}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
